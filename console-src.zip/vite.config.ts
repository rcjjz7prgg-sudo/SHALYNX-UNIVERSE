import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' so the build works from any sub-folder (GitHub Pages serves it at /SHALYNX-UNIVERSE/console/)
export default defineConfig({
  base: './',
  plugins: [react()],
  build: { sourcemap: false, target: 'es2020' },
});
