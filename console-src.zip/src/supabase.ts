import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = 'https://bvqspkbjdnblxmikkvar.supabase.co';
// Publishable key: designed to be public. Real protection is Row Level Security in the database.
const PUBLISHABLE_KEY = 'sb_publishable_ClpBYDbYC6H5ZlrerQPJ6Q_WtvRWm3j';

// sessionStorage: the session ends when the tab closes. (localStorage would keep it indefinitely.)
export const supabase = createClient(SUPABASE_URL, PUBLISHABLE_KEY, {
  auth: { persistSession: true, storage: window.sessionStorage, autoRefreshToken: true, detectSessionInUrl: false },
});
