import { useState } from 'react';
import { supabase } from '../supabase';
import { ErrorBox, errMsg, Loading, unwrap, useAsync, useAuth, useToast } from '../lib';

interface Enrol { id: string; qr: string; secret: string }

export default function Security() {
  const auth = useAuth();
  const toast = useToast();
  const factors = useAsync(async () => {
    const f = unwrap(await supabase.auth.mfa.listFactors());
    // clear abandoned, never-verified enrolments so a new QR code can be created
    for (const x of f.all.filter((a) => a.status === 'unverified')) await supabase.auth.mfa.unenroll({ factorId: x.id });
    return f.totp;
  }, []);
  const [enrol, setEnrol] = useState<Enrol | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);

  async function start() {
    setBusy(true);
    try {
      const d = unwrap(await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'Authenticator ' + new Date().toISOString().slice(0, 10) }));
      setEnrol({ id: d.id, qr: d.totp.qr_code, secret: d.totp.secret });
    } catch (e) { toast(errMsg(e), 'err'); } finally { setBusy(false); }
  }
  async function verify() {
    if (!enrol) return;
    setBusy(true);
    try {
      const r = await supabase.auth.mfa.challengeAndVerify({ factorId: enrol.id, code: code.trim() });
      if (r.error) throw new Error(r.error.message);
      toast('Two-step verification is on for your account.'); setEnrol(null); setCode(''); factors.reload(); auth.refresh();
    } catch (e) { toast(errMsg(e), 'err'); } finally { setBusy(false); }
  }
  async function remove(id: string) {
    if (!window.confirm('Remove this authenticator? Your account will be less protected.')) return;
    try { const r = await supabase.auth.mfa.unenroll({ factorId: id }); if (r.error) throw new Error(r.error.message); toast('Removed'); factors.reload(); auth.refresh(); }
    catch (e) { toast(errMsg(e), 'err'); }
  }
  async function everywhere() {
    if (!window.confirm('Sign out of every device?')) return;
    await supabase.auth.signOut({ scope: 'global' });
  }

  const verified = (factors.data ?? []).filter((f) => f.status === 'verified');
  return (
    <>
      <h1>My security</h1>
      <section className="card">
        <h2>Two-step verification</h2>
        <p className="mut">Uses an authenticator app (Google Authenticator, Microsoft Authenticator, Authy…). This session is {auth.aal === 'aal2' ? 'verified with two steps.' : 'password-only.'}</p>
        {factors.loading && <Loading />}
        {factors.error && <ErrorBox message={factors.error} retry={factors.reload} />}
        {verified.map((f) => (
          <div key={f.id} className="row between"><span>{f.friendly_name ?? 'Authenticator'} <span className="pill st-active">active</span></span><button type="button" className="bad" onClick={() => void remove(f.id)}>Remove</button></div>
        ))}
        {!factors.loading && verified.length === 0 && !enrol && <button type="button" disabled={busy} onClick={() => void start()}>Set up an authenticator</button>}
        {enrol && (
          <div>
            <p>1. Scan this code in your authenticator app (or enter the key by hand).</p>
            <img src={enrol.qr} alt="QR code for your authenticator app" className="qr" />
            <p className="small">Key: <code>{enrol.secret}</code></p>
            <p>2. Enter the 6-digit code it shows.</p>
            <input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} aria-label="6-digit code" />
            <div className="row"><button type="button" disabled={busy} onClick={() => void verify()}>Verify and turn on</button><button type="button" className="sec" onClick={() => setEnrol(null)}>Cancel</button></div>
          </div>
        )}
      </section>
      <section className="card">
        <h2>Sessions</h2>
        <p className="mut">This sign-in ends when you close the tab.</p>
        <button type="button" className="sec" onClick={() => void everywhere()}>Sign out everywhere</button>
      </section>
    </>
  );
}
