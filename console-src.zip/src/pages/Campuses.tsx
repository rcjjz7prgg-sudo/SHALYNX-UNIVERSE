import { useState } from 'react';
import type { FormEvent } from 'react';
import { supabase } from '../supabase';
import { Empty, ErrorBox, errMsg, Loading, Pill, unwrap, useAsync, useAuth, useToast } from '../lib';
import type { Institution } from '../types';

interface Draft { id: string; name: string; short_name: string; location: string; description: string; visibility: 'public' | 'hidden'; logo_url: string }
const blank: Draft = { id: '', name: '', short_name: '', location: '', description: '', visibility: 'public', logo_url: '' };
const SLUG = /^[a-z][a-z0-9-]{1,23}$/;

export default function Campuses() {
  const auth = useAuth();
  const toast = useToast();
  const list = useAsync(async () => unwrap(await supabase.from('institutions').select('*').is('deleted_at', null).order('short_name')) as Institution[], []);
  const [editing, setEditing] = useState<string | 'new' | null>(null);
  const [d, setD] = useState<Draft>(blank);
  const [busy, setBusy] = useState(false);

  function edit(c: Institution) {
    setEditing(c.id);
    setD({ id: c.id, name: c.name, short_name: c.short_name, location: c.location ?? '', description: c.description ?? '', visibility: c.visibility, logo_url: c.logo_url ?? '' });
  }
  async function save(e: FormEvent) {
    e.preventDefault();
    if (editing === 'new' && !SLUG.test(d.id)) { toast('Slug: lowercase letters, numbers and hyphens, starting with a letter (2-24 characters).', 'err'); return; }
    if (d.name.trim().length < 2 || d.short_name.trim().length < 2) { toast('Enter the full name and a short name.', 'err'); return; }
    if (d.logo_url && !/^https:\/\//.test(d.logo_url)) { toast('Logo URL must start with https://', 'err'); return; }
    setBusy(true);
    try {
      const row = {
        name: d.name.trim(), short_name: d.short_name.trim(), location: d.location.trim() || null,
        description: d.description.trim() || null, visibility: d.visibility, logo_url: d.logo_url.trim() || null,
      };
      if (editing === 'new') unwrap(await supabase.from('institutions').insert({ id: d.id, ...row }).select('id').single());
      else {
        const r = await supabase.from('institutions').update(row).eq('id', d.id).select('id');
        if (r.error) throw new Error(r.error.message);
        if (!r.data || r.data.length === 0) throw new Error('Nothing was changed. You may not have permission to edit this campus.');
      }
      toast(editing === 'new' ? 'Campus created' : 'Campus saved');
      setEditing(null); list.reload();
    } catch (err) { toast(errMsg(err), 'err'); } finally { setBusy(false); }
  }
  async function toggle(c: Institution) {
    const next = !c.active;
    const msg = next ? `Activate ${c.short_name}? It becomes visible on the public site again.` : `Deactivate ${c.short_name}? It disappears from the public site. Data is kept.`;
    if (!window.confirm(msg)) return;
    try {
      const r = await supabase.from('institutions').update({ active: next }).eq('id', c.id).select('id');
      if (r.error) throw new Error(r.error.message);
      if (!r.data || r.data.length === 0) throw new Error('Nothing was changed. You may not have permission.');
      toast(next ? 'Campus activated' : 'Campus deactivated'); list.reload();
    } catch (err) { toast(errMsg(err), 'err'); }
  }

  return (
    <>
      <h1>Campuses</h1>
      {auth.can('campuses.create') && editing === null && <p><button type="button" onClick={() => { setEditing('new'); setD(blank); }}>Add a university</button></p>}

      {editing !== null && (
        <form className="card" onSubmit={save}>
          <h2>{editing === 'new' ? 'New university' : `Edit ${d.short_name}`}</h2>
          <label>Slug (permanent web id)
            <input value={d.id} disabled={editing !== 'new'} maxLength={24} placeholder="e.g. unilag" onChange={(e) => setD({ ...d, id: e.target.value.toLowerCase() })} />
          </label>
          <label>Full name<input value={d.name} maxLength={120} onChange={(e) => setD({ ...d, name: e.target.value })} /></label>
          <label>Short name<input value={d.short_name} maxLength={30} onChange={(e) => setD({ ...d, short_name: e.target.value })} /></label>
          <label>Location<input value={d.location} maxLength={120} onChange={(e) => setD({ ...d, location: e.target.value })} /></label>
          <label>Description<textarea value={d.description} maxLength={1000} rows={3} onChange={(e) => setD({ ...d, description: e.target.value })} /></label>
          <label>Logo URL (https)<input value={d.logo_url} maxLength={300} onChange={(e) => setD({ ...d, logo_url: e.target.value })} /></label>
          <label>Visibility
            <select value={d.visibility} onChange={(e) => setD({ ...d, visibility: e.target.value as 'public' | 'hidden' })}>
              <option value="public">Public</option><option value="hidden">Hidden (staff only)</option>
            </select>
          </label>
          <div className="row">
            <button type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
            <button type="button" className="sec" onClick={() => setEditing(null)}>Cancel</button>
          </div>
        </form>
      )}

      {list.loading && <Loading what="campuses" />}
      {list.error && <ErrorBox message={list.error} retry={list.reload} />}
      {list.data && list.data.length === 0 && <Empty>No campuses yet.</Empty>}
      <div className="scroll">
        {list.data && list.data.length > 0 && (
          <table>
            <thead><tr><th>Campus</th><th>Slug</th><th>Status</th><th>Visibility</th><th /></tr></thead>
            <tbody>{list.data.map((c) => (
              <tr key={c.id}>
                <td><b>{c.short_name}</b><div className="mut small">{c.name}{c.location ? ' · ' + c.location : ''}</div></td>
                <td><code>{c.id}</code></td>
                <td><Pill status={c.active ? 'active' : 'suspended'} /></td>
                <td>{c.visibility}</td>
                <td className="acts">
                  {auth.can('campuses.update') && <button type="button" className="sec" onClick={() => edit(c)}>Edit</button>}
                  {auth.can('campuses.deactivate') && <button type="button" className={c.active ? 'bad' : 'sec'} onClick={() => void toggle(c)}>{c.active ? 'Deactivate' : 'Activate'}</button>}
                </td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </>
  );
}
