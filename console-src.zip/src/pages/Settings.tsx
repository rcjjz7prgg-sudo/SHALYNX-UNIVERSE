import { supabase } from '../supabase';
import { ErrorBox, errMsg, fmtDate, Loading, unwrap, useAsync, useAuth, useToast } from '../lib';
import type { SettingRow } from '../types';

const INFO: Record<string, { title: string; help: string; warn?: string }> = {
  'workflow.allow_self_approval': {
    title: 'Allow reviewers to approve their own content',
    help: 'Off (recommended): someone else must approve every article. Turn on only while you are the only reviewer.',
    warn: 'Turning this on removes the two-person check. Continue?',
  },
  'registration_open': { title: 'Student registration open', help: 'When off, new students cannot sign up.' },
  'maintenance_mode': { title: 'Maintenance mode', help: 'Flag for the public site. Not enforced anywhere yet.' },
  'security.require_mfa_for_staff': {
    title: 'Require two-step verification for all staff',
    help: 'When on, staff without a verified authenticator lose all admin power until they enrol and sign in again.',
    warn: 'Make sure every staff member has enrolled an authenticator first, or they will be locked out. Continue?',
  },
};

export default function Settings() {
  const auth = useAuth();
  const toast = useToast();
  const data = useAsync(async () => unwrap(await supabase.from('system_settings').select('key,value,updated_at').order('key')) as SettingRow[], []);

  async function flip(row: SettingRow) {
    const next = row.value !== true;
    const info = INFO[row.key];
    if (row.key === 'security.require_mfa_for_staff' && next && auth.aal !== 'aal2') {
      toast('Enrol and verify two-step verification on your own account first (My security), then sign in again.', 'err'); return;
    }
    if (next && info?.warn && !window.confirm(info.warn)) return;
    try {
      const r = await supabase.rpc('set_system_setting', { p_key: row.key, p_value: next });
      if (r.error) throw new Error(r.error.message);
      toast('Setting saved'); data.reload();
    } catch (e) { toast(errMsg(e), 'err'); }
  }

  return (
    <>
      <h1>Settings</h1>
      {data.loading && <Loading what="settings" />}
      {data.error && <ErrorBox message={data.error} retry={data.reload} />}
      {(data.data ?? []).map((s) => {
        const on = s.value === true;
        const info = INFO[s.key];
        return (
          <section className="card" key={s.key}>
            <div className="row between">
              <div><b>{info?.title ?? s.key}</b><p className="mut small">{info?.help}</p><p className="mut small">Last changed {fmtDate(s.updated_at)}</p></div>
              <button type="button" className={on ? 'sec' : ''} disabled={!auth.can('settings.manage')} aria-pressed={on} onClick={() => void flip(s)}>{on ? 'On — turn off' : 'Off — turn on'}</button>
            </div>
          </section>
        );
      })}
      {!auth.can('settings.manage') && <p className="mut">You can view settings but not change them.</p>}
    </>
  );
}
