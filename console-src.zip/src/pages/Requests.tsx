import { useState } from 'react';
import { supabase } from '../supabase';
import { Empty, ErrorBox, errMsg, fmtDate, Loading, Pill, unwrap, useAsync, useAuth, useToast } from '../lib';
import type { Institution, NoteRow, RequestRow } from '../types';

const PAGE = 20;
const STATUSES = ['submitted', 'under_review', 'awaiting_information', 'in_progress', 'completed', 'cancelled'];

function Detail({ r, onChanged }: { r: RequestRow; onChanged: () => void }) {
  const auth = useAuth();
  const toast = useToast();
  const [note, setNote] = useState('');
  const notes = useAsync(async () => unwrap(await supabase.from('request_notes').select('id,author,note,created_at').eq('request_id', r.id).order('created_at')) as NoteRow[], [r.id]);

  async function setStatus(status: string) {
    try {
      const res = await supabase.from('service_requests').update({ status }).eq('id', r.id).select('id');
      if (res.error) throw new Error(res.error.message);
      if (!res.data?.length) throw new Error('Nothing was changed. You may not have permission.');
      toast('Status updated'); onChanged();
    } catch (e) { toast(errMsg(e), 'err'); }
  }
  async function addNote() {
    if (note.trim().length < 2) return;
    try {
      const res = await supabase.from('request_notes').insert({ request_id: r.id, author: auth.userId, note: note.trim() });
      if (res.error) throw new Error(res.error.message);
      setNote(''); toast('Note added'); notes.reload();
    } catch (e) { toast(errMsg(e), 'err'); }
  }
  return (
    <div className="detail">
      <p style={{ whiteSpace: 'pre-wrap' }}>{r.message}</p>
      <p className="mut small">{r.contact_name ?? 'No name'} · {r.contact_phone ?? 'no phone'} · received {fmtDate(r.created_at)}</p>
      {auth.can('requests.update') && (
        <label>Status
          <select value={r.status} onChange={(e) => void setStatus(e.target.value)}>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select>
        </label>
      )}
      <h3>Internal notes</h3>
      {notes.loading ? <Loading /> : notes.error ? <ErrorBox message={notes.error} retry={notes.reload} /> : (
        (notes.data ?? []).length === 0 ? <Empty>No notes yet.</Empty> : <ul className="plain">{(notes.data ?? []).map((n) => <li key={n.id}>{n.note} <span className="mut small">{fmtDate(n.created_at)}</span></li>)}</ul>
      )}
      {auth.can('requests.notes') && (
        <div className="row"><input value={note} maxLength={1000} placeholder="Add a note (staff only)" onChange={(e) => setNote(e.target.value)} /><button type="button" onClick={() => void addNote()}>Add</button></div>
      )}
    </div>
  );
}

export default function Requests() {
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState('');
  const [campus, setCampus] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const camps = useAsync(async () => unwrap(await supabase.from('institutions').select('id,short_name').order('short_name')) as Pick<Institution, 'id' | 'short_name'>[], []);
  const rows = useAsync(async () => {
    let q = supabase.from('service_requests')
      .select('id,reference,institution_id,category,status,message,contact_name,contact_phone,created_at', { count: 'exact' })
      .order('created_at', { ascending: false }).range(page * PAGE, page * PAGE + PAGE - 1);
    if (status) q = q.eq('status', status);
    if (campus) q = q.eq('institution_id', campus);
    const res = await q;
    if (res.error) throw new Error(res.error.message);
    return { list: (res.data ?? []) as RequestRow[], total: res.count ?? 0 };
  }, [page, status, campus]);
  const total = rows.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <>
      <h1>Support requests</h1>
      <div className="filters">
        <label>Status<select value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}><option value="">All</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}</select></label>
        <label>Campus<select value={campus} onChange={(e) => { setCampus(e.target.value); setPage(0); }}><option value="">All</option>{(camps.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.short_name}</option>)}</select></label>
      </div>
      {rows.loading && <Loading what="requests" />}
      {rows.error && <ErrorBox message={rows.error} retry={rows.reload} />}
      {rows.data && rows.data.list.length === 0 && <Empty>No requests match. New student requests appear here.</Empty>}
      {rows.data?.list.map((r) => (
        <div className="card" key={r.id}>
          <button type="button" className="rolehead" aria-expanded={open === r.id} onClick={() => setOpen(open === r.id ? null : r.id)}>
            <b>{r.reference ?? r.id.slice(0, 8)}</b><span>{r.category} · {r.institution_id.toUpperCase()}</span><Pill status={r.status} />
          </button>
          {open === r.id && <Detail r={r} onChanged={rows.reload} />}
        </div>
      ))}
      <div className="row pager">
        <button type="button" className="sec" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button>
        <span className="mut">Page {page + 1} of {pages} · {total} requests</span>
        <button type="button" className="sec" disabled={page + 1 >= pages} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </>
  );
}
