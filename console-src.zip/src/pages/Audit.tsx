import { Fragment, useState } from 'react';
import { supabase } from '../supabase';
import { Empty, ErrorBox, fmtDate, Loading, unwrap, useAsync } from '../lib';
import type { AuditRow, Institution, StaffProfile } from '../types';

const PAGE = 25;

export default function Audit() {
  const [page, setPage] = useState(0);
  const [action, setAction] = useState('');
  const [campus, setCampus] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [open, setOpen] = useState<number | null>(null);

  const camps = useAsync(async () => unwrap(await supabase.from('institutions').select('id,short_name').order('short_name')) as Pick<Institution, 'id' | 'short_name'>[], []);
  const rows = useAsync(async () => {
    let q = supabase.from('audit_logs')
      .select('id,created_at,actor,actor_role,action,entity_table,entity_id,institution_id,before_data,after_data', { count: 'exact' })
      .order('created_at', { ascending: false }).range(page * PAGE, page * PAGE + PAGE - 1);
    if (action.trim()) q = q.ilike('action', action.trim().replace(/[%,()]/g, '') + '%');
    if (campus) q = q.eq('institution_id', campus);
    if (from) q = q.gte('created_at', new Date(from + 'T00:00:00').toISOString());
    if (to) q = q.lte('created_at', new Date(to + 'T23:59:59').toISOString());
    const res = await q;
    if (res.error) throw new Error(res.error.message);
    const list = (res.data ?? []) as AuditRow[];
    const ids = Array.from(new Set(list.map((r) => r.actor).filter((x): x is string => !!x)));
    let names: Record<string, string> = {};
    if (ids.length) {
      const st = await supabase.from('staff_profiles').select('user_id,full_name').in('user_id', ids);
      names = Object.fromEntries(((st.data ?? []) as Pick<StaffProfile, 'user_id' | 'full_name'>[]).map((s) => [s.user_id, s.full_name]));
    }
    return { list, names, total: res.count ?? 0 };
  }, [page, action, campus, from, to]);

  const reset = <T,>(set: (v: T) => void) => (v: T) => { set(v); setPage(0); };
  const total = rows.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <>
      <h1>Audit log</h1>
      <p className="mut">Append-only. Nobody, including administrators, can edit or delete these records.</p>
      <div className="filters">
        <label>Action starts with<input value={action} placeholder="e.g. role. or content." onChange={(e) => reset(setAction)(e.target.value)} /></label>
        <label>Campus
          <select value={campus} onChange={(e) => reset(setCampus)(e.target.value)}>
            <option value="">All</option>{(camps.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.short_name}</option>)}
          </select>
        </label>
        <label>From<input type="date" value={from} onChange={(e) => reset(setFrom)(e.target.value)} /></label>
        <label>To<input type="date" value={to} onChange={(e) => reset(setTo)(e.target.value)} /></label>
      </div>
      {rows.loading && <Loading what="records" />}
      {rows.error && <ErrorBox message={rows.error} retry={rows.reload} />}
      {rows.data && rows.data.list.length === 0 && <Empty>No records match.</Empty>}
      {rows.data && rows.data.list.length > 0 && (
        <div className="scroll"><table>
          <thead><tr><th>When</th><th>Who</th><th>Action</th><th>What</th><th>Campus</th></tr></thead>
          <tbody>{rows.data.list.map((r) => (
            <Fragment key={r.id}>
              <tr className="clickable" onClick={() => setOpen(open === r.id ? null : r.id)}>
                <td>{fmtDate(r.created_at)}</td>
                <td>{r.actor ? (rows.data!.names[r.actor] ?? r.actor.slice(0, 8)) : 'system'}{r.actor_role && <div className="mut small">{r.actor_role}</div>}</td>
                <td><b>{r.action}</b></td><td>{r.entity_table}</td><td>{r.institution_id ?? '—'}</td>
              </tr>
              {open === r.id && (
                <tr><td colSpan={5}><pre>{JSON.stringify({ before: r.before_data, after: r.after_data, entity_id: r.entity_id }, null, 2)}</pre></td></tr>
              )}
            </Fragment>
          ))}</tbody>
        </table></div>
      )}
      <div className="row pager">
        <button type="button" className="sec" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</button>
        <span className="mut">Page {page + 1} of {pages} · {total} records</span>
        <button type="button" className="sec" disabled={page + 1 >= pages} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </>
  );
}
