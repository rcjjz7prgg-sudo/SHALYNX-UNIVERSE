import { useState } from 'react';
import { supabase } from '../supabase';
import { Empty, ErrorBox, fmtDate, Loading, unwrap, useAsync, useAuth } from '../lib';
import type { AuditRow, CampusStat, DashStats, Institution, TrendPoint } from '../types';

interface Card { label: string; value: number | string; href?: string; hint?: string }

function TrendChart({ points }: { points: TrendPoint[] }) {
  const max = Math.max(1, ...points.map((p) => p.registrations));
  const w = 600, h = 120, bw = w / Math.max(points.length, 1);
  return (
    <svg viewBox={`0 0 ${w} ${h + 18}`} className="chart" role="img" aria-label="New student registrations per day">
      {points.map((p, i) => {
        const bh = Math.round((p.registrations / max) * h);
        return (
          <g key={p.day}>
            <rect x={i * bw + 1} y={h - bh} width={Math.max(bw - 2, 1)} height={bh} rx="2" className="bar"><title>{`${p.day}: ${p.registrations}`}</title></rect>
          </g>
        );
      })}
      <text x="0" y={h + 14} className="axis">{points[0]?.day ?? ''}</text>
      <text x={w} y={h + 14} textAnchor="end" className="axis">{points[points.length - 1]?.day ?? ''}</text>
    </svg>
  );
}

export default function Dashboard() {
  const auth = useAuth();
  const [days, setDays] = useState(30);
  const [campus, setCampus] = useState('');
  const inst = campus || null;

  const camps = useAsync(async () => unwrap(await supabase.from('institutions').select('id,short_name').order('short_name')) as Pick<Institution, 'id' | 'short_name'>[], []);
  const stats = useAsync(async () => unwrap(await supabase.rpc('dashboard_stats', { p_days: days, p_institution: inst })) as DashStats, [days, campus]);
  const trend = useAsync(async () => unwrap(await supabase.rpc('registrations_trend', { p_days: days, p_institution: inst })) as TrendPoint[], [days, campus]);
  const compare = useAsync(async () => unwrap(await supabase.rpc('campus_stats')) as CampusStat[], []);
  const recent = useAsync(async () => {
    if (!auth.can('audit.view')) return [] as AuditRow[];
    return unwrap(await supabase.from('audit_logs').select('id,created_at,actor_role,action,entity_table,institution_id').order('created_at', { ascending: false }).limit(8)) as AuditRow[];
  }, []);

  const s = stats.data;
  const cards: Card[] = s ? [
    { label: 'Registered students', value: s.students, hint: `+${s.new_students} in last ${days} days` },
    { label: 'Campuses active', value: `${s.campuses_active} / ${s.campuses_total}`, href: '#/campuses' },
    { label: 'Active staff', value: s.staff_active, href: '#/staff' },
    { label: 'Pending invitations', value: s.staff_invited, href: '#/staff' },
    { label: 'Published articles', value: s.articles_published },
    { label: 'Awaiting review', value: s.reviews_pending },
    { label: 'Published opportunities', value: s.opportunities_published },
    { label: 'Open support requests', value: s.requests_open, href: '#/requests' },
  ] : [];

  return (
    <>
      <h1>Overview</h1>
      <div className="filters">
        <label>Period
          <select value={days} onChange={(e) => setDays(Number(e.target.value))}>
            <option value={7}>Last 7 days</option><option value={30}>Last 30 days</option><option value={90}>Last 90 days</option>
          </select>
        </label>
        <label>Campus
          <select value={campus} onChange={(e) => setCampus(e.target.value)}>
            <option value="">All I can see</option>
            {(camps.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.short_name}</option>)}
          </select>
        </label>
      </div>

      {stats.loading && <Loading what="figures" />}
      {stats.error && <ErrorBox message={stats.error} retry={stats.reload} />}
      <div className="grid">
        {cards.map((c) => {
          const inner = (<><span className="num">{c.value}</span><span className="lbl">{c.label}</span>{c.hint && <span className="hint">{c.hint}</span>}</>);
          return c.href ? <a key={c.label} className="stat" href={c.href}>{inner}</a> : <div key={c.label} className="stat">{inner}</div>;
        })}
      </div>
      <p className="mut small">Counts reflect only what your role is allowed to see. Active-user and reported-content figures will appear when those features go live; they are not estimated.</p>

      <section className="card">
        <h2>New student registrations</h2>
        {trend.loading ? <Loading /> : trend.error ? <ErrorBox message={trend.error} retry={trend.reload} /> : (trend.data && trend.data.length > 0 ? <TrendChart points={trend.data} /> : <Empty>No registrations in this period.</Empty>)}
      </section>

      <section className="card">
        <h2>Campus comparison</h2>
        {compare.loading ? <Loading /> : compare.error ? <ErrorBox message={compare.error} retry={compare.reload} /> : (
          <div className="scroll"><table>
            <thead><tr><th>Campus</th><th>Students</th><th>Open requests</th><th>Published articles</th><th>Awaiting review</th></tr></thead>
            <tbody>{(compare.data ?? []).map((c) => (
              <tr key={c.institution_id}><td>{c.short_name}</td><td>{c.students}</td><td>{c.open_requests}</td><td>{c.published_articles}</td><td>{c.pending_reviews}</td></tr>
            ))}</tbody>
          </table></div>
        )}
      </section>

      {auth.can('audit.view') && (
        <section className="card">
          <h2>Recent administrative activity</h2>
          {recent.loading ? <Loading /> : recent.error ? <ErrorBox message={recent.error} retry={recent.reload} /> : (recent.data && recent.data.length > 0 ? (
            <ul className="plain">{recent.data.map((r) => <li key={r.id}><b>{r.action}</b> <span className="mut">{r.entity_table}{r.institution_id ? ' · ' + r.institution_id.toUpperCase() : ''} · {fmtDate(r.created_at)}</span></li>)}</ul>
          ) : <Empty>No activity recorded yet.</Empty>)}
          <p><a href="#/audit">Open full audit log →</a></p>
        </section>
      )}
    </>
  );
}
