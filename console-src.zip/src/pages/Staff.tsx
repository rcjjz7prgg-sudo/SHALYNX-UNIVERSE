import { useState } from 'react';
import { supabase } from '../supabase';
import { Empty, ErrorBox, errMsg, fmtDate, fnError, Loading, Pill, unwrap, useAsync, useAuth, useToast } from '../lib';
import type { Institution, Role, StaffProfile, UserRole } from '../types';

interface InviteResult { delivery: string; message: string; invite_link: string | null }

export default function Staff() {
  const auth = useAuth();
  const toast = useToast();
  const data = useAsync(async () => {
    const [s, r, roles, inst] = await Promise.all([
      supabase.from('staff_profiles').select('user_id,full_name,status,last_seen_at').order('created_at'),
      supabase.from('user_roles').select('id,user_id,role_key,institution_id').is('revoked_at', null),
      supabase.from('roles').select('key,name,scope_type,rank').order('rank', { ascending: false }),
      supabase.from('institutions').select('id,short_name').is('deleted_at', null).order('short_name'),
    ]);
    return {
      staff: unwrap(s) as StaffProfile[], assignments: unwrap(r) as UserRole[],
      roles: unwrap(roles) as Role[], campuses: unwrap(inst) as Pick<Institution, 'id' | 'short_name'>[],
    };
  }, []);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [campus, setCampus] = useState('');
  const [mode, setMode] = useState<'link' | 'email'>('link');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<InviteResult | null>(null);

  const roles = data.data?.roles ?? [];
  const selected = roles.find((r) => r.key === role);
  const roleName = (k: string) => roles.find((r) => r.key === k)?.name ?? k;

  async function invite() {
    if (!selected) { toast('Choose a role.', 'err'); return; }
    if (!name.trim() || !email.trim()) { toast('Enter the name and email.', 'err'); return; }
    const inst = selected.scope_type === 'campus' ? (campus || data.data?.campuses[0]?.id || null) : null;
    setBusy(true); setResult(null);
    const { data: res, error } = await supabase.functions.invoke('invite-staff', {
      body: { email: email.trim(), full_name: name.trim(), role: selected.key, institution_id: inst, mode },
    });
    setBusy(false);
    if (error) { toast('Not done: ' + (await fnError(error)), 'err'); return; }
    setResult(res as InviteResult); setName(''); setEmail('');
    toast('Invitation created', 'ok'); data.reload();
  }

  async function act(s: StaffProfile, action: 'suspend' | 'reinstate' | 'revoke') {
    let reason = '';
    if (action === 'reinstate') { if (!window.confirm(`Reinstate ${s.full_name}?`)) return; }
    else { const r = window.prompt(`${action === 'revoke' ? 'Revoke all access for' : 'Suspend'} ${s.full_name}? Add a short reason (optional):`); if (r === null) return; reason = r; }
    const { data: res, error } = await supabase.functions.invoke('suspend-user', { body: { user_id: s.user_id, action, reason } });
    if (error) { toast('Not done: ' + (await fnError(error)), 'err'); return; }
    toast((res as { message?: string }).message ?? 'Done'); data.reload();
  }
  async function removeRole(a: UserRole) {
    if (!window.confirm(`Remove the ${roleName(a.role_key)} role?`)) return;
    try { const r = await supabase.rpc('revoke_role', { p_role_id: a.id }); if (r.error) throw new Error(r.error.message); toast('Role removed'); data.reload(); }
    catch (e) { toast(errMsg(e), 'err'); }
  }

  const campusRole = selected?.scope_type === 'campus';
  return (
    <>
      <h1>Staff & access</h1>
      {auth.can('admins.invite') && (
        <section className="card">
          <h2>Invite a staff member</h2>
          <label>Full name<input value={name} maxLength={120} onChange={(e) => setName(e.target.value)} /></label>
          <label>Email<input type="email" value={email} maxLength={254} onChange={(e) => setEmail(e.target.value)} /></label>
          <label>Role
            <select value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="">Choose…</option>
              {roles.map((r) => <option key={r.key} value={r.key}>{r.name} ({r.scope_type})</option>)}
            </select>
          </label>
          {campusRole && (
            <label>Campus
              <select value={campus || data.data?.campuses[0]?.id || ''} onChange={(e) => setCampus(e.target.value)}>
                {(data.data?.campuses ?? []).map((c) => <option key={c.id} value={c.id}>{c.short_name}</option>)}
              </select>
            </label>
          )}
          <label>Delivery
            <select value={mode} onChange={(e) => setMode(e.target.value as 'link' | 'email')}>
              <option value="link">Give me a link to send myself</option>
              <option value="email">Ask the system to email it (needs mail provider)</option>
            </select>
          </label>
          <button type="button" disabled={busy} onClick={() => void invite()}>{busy ? 'Creating…' : 'Create invitation'}</button>
          {result && (
            <div className={result.delivery === 'email_requested' ? 'msg warn' : 'msg ok'}>
              <p>{result.message}</p>
              {result.invite_link && (<>
                <p className="small">One-time link. It is shown only now. Send it only to the invitee and do not post it anywhere.</p>
                <input readOnly value={result.invite_link} onFocus={(e) => e.currentTarget.select()} />
                <button type="button" className="sec" onClick={() => void navigator.clipboard?.writeText(result.invite_link ?? '').then(() => toast('Copied'), () => toast('Press and hold the link to copy it.', 'warn'))}>Copy link</button>
              </>)}
            </div>
          )}
        </section>
      )}

      <section className="card">
        <h2>Staff</h2>
        {data.loading && <Loading what="staff" />}
        {data.error && <ErrorBox message={data.error} retry={data.reload} />}
        {data.data && data.data.staff.length === 0 && <Empty>No staff visible to you yet.</Empty>}
        <div className="scroll">
          {data.data && data.data.staff.length > 0 && (
            <table>
              <thead><tr><th>Name</th><th>Roles</th><th>Status</th><th /></tr></thead>
              <tbody>{data.data.staff.map((s) => {
                const mine = data.data!.assignments.filter((a) => a.user_id === s.user_id);
                const self = s.user_id === auth.userId;
                return (
                  <tr key={s.user_id}>
                    <td><b>{s.full_name}</b>{self && <span className="mut"> (you)</span>}<div className="mut small">Last seen {fmtDate(s.last_seen_at)}</div></td>
                    <td>{mine.length === 0 ? '—' : mine.map((a) => (
                      <div key={a.id} className="small">{roleName(a.role_key)}{a.institution_id ? ' · ' + a.institution_id.toUpperCase() : ''}
                        {!self && auth.can('admins.revoke_access') && <button type="button" className="link" onClick={() => void removeRole(a)}> remove</button>}
                      </div>))}</td>
                    <td><Pill status={s.status} /></td>
                    <td className="acts">{!self && (<>
                      {(s.status === 'active' || s.status === 'invited') && auth.can('admins.suspend') && <button type="button" className="sec" onClick={() => void act(s, 'suspend')}>Suspend</button>}
                      {(s.status === 'suspended' || s.status === 'revoked') && auth.can('admins.suspend') && <button type="button" className="sec" onClick={() => void act(s, 'reinstate')}>Reinstate</button>}
                      {s.status !== 'revoked' && auth.can('admins.revoke_access') && <button type="button" className="bad" onClick={() => void act(s, 'revoke')}>Revoke</button>}
                    </>)}</td>
                  </tr>
                );
              })}</tbody>
            </table>
          )}
        </div>
      </section>
    </>
  );
}
