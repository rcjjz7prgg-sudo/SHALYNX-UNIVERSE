import { useState } from 'react';
import { supabase } from '../supabase';
import { ErrorBox, Loading, unwrap, useAsync } from '../lib';
import type { Role } from '../types';

interface RolePerm { role_key: string; permission_key: string }

export default function Roles() {
  const data = useAsync(async () => {
    const [r, rp] = await Promise.all([
      supabase.from('roles').select('key,name,scope_type,rank').order('rank', { ascending: false }),
      supabase.from('role_permissions').select('role_key,permission_key').order('permission_key').limit(1000),
    ]);
    return { roles: unwrap(r) as Role[], perms: unwrap(rp) as RolePerm[] };
  }, []);
  const [open, setOpen] = useState<string | null>(null);

  if (data.loading) return <Loading what="roles" />;
  if (data.error || !data.data) return <ErrorBox message={data.error ?? 'Could not load roles'} retry={data.reload} />;
  const byRole = (k: string) => data.data!.perms.filter((p) => p.role_key === k).map((p) => p.permission_key);
  const group = (keys: string[]) => keys.reduce<Record<string, string[]>>((acc, k) => { const [m, a] = k.split('.'); (acc[m] ??= []).push(a); return acc; }, {});

  return (
    <>
      <h1>Roles & permissions</h1>
      <p className="mut">Read-only. Higher rank outranks lower rank: you can only grant or remove roles ranked below your own. Global roles apply to every campus; campus roles apply to one campus.</p>
      {(['global', 'campus'] as const).map((scope) => (
        <section className="card" key={scope}>
          <h2>{scope === 'global' ? 'Global roles' : 'Campus roles'}</h2>
          {data.data!.roles.filter((r) => r.scope_type === scope).map((r) => {
            const keys = byRole(r.key);
            const isOpen = open === r.key;
            return (
              <div key={r.key} className="role">
                <button type="button" className="rolehead" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : r.key)}>
                  <b>{r.name}</b><span className="mut small">rank {r.rank} · {keys.length} permissions</span>
                </button>
                {isOpen && (
                  <dl className="perms">
                    {Object.entries(group(keys)).map(([m, acts]) => (<div key={m}><dt>{m}</dt><dd>{acts.join(', ')}</dd></div>))}
                  </dl>
                )}
              </div>
            );
          })}
        </section>
      ))}
    </>
  );
}
