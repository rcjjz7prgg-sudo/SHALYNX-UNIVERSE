export interface Perm { permission_key: string; institution_id: string | null }
export interface Institution {
  id: string; name: string; short_name: string; location: string | null; accent: string | null;
  active: boolean; description: string | null; logo_url: string | null; visibility: 'public' | 'hidden'; timezone: string;
}
export interface Role { key: string; name: string; scope_type: 'global' | 'campus'; rank: number }
export interface StaffProfile { user_id: string; full_name: string; status: 'invited' | 'active' | 'suspended' | 'revoked'; last_seen_at: string | null }
export interface UserRole { id: string; user_id: string; role_key: string; institution_id: string | null }
export interface DashStats {
  students: number; new_students: number; campuses_active: number; campuses_total: number;
  staff_active: number; staff_invited: number; articles_published: number; reviews_pending: number;
  opportunities_published: number; requests_open: number;
}
export interface CampusStat { institution_id: string; short_name: string; students: number; open_requests: number; published_articles: number; pending_reviews: number }
export interface TrendPoint { day: string; registrations: number }
export interface AuditRow {
  id: number; created_at: string; actor: string | null; actor_role: string | null; action: string;
  entity_table: string; entity_id: string | null; institution_id: string | null; before_data: unknown; after_data: unknown;
}
export interface RequestRow {
  id: string; reference: string | null; institution_id: string; category: string; status: string; message: string;
  contact_name: string | null; contact_phone: string | null; created_at: string;
}
export interface NoteRow { id: number; author: string; note: string; created_at: string }
export interface SettingRow { key: string; value: unknown; updated_at: string }
