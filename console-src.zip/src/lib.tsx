import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';

export const errMsg = (e: unknown): string => (e instanceof Error ? e.message : typeof e === 'string' ? e : 'Something went wrong');

/** Throws on a Supabase error so callers never show success when the database refused. */
export function unwrap<T>(res: { data: T | null; error: { message: string } | null }): T {
  if (res.error) throw new Error(res.error.message);
  return res.data as T;
}

/** Reads the JSON body of a failed Edge Function call to show the real reason. */
export async function fnError(e: unknown): Promise<string> {
  const ctx = (e as { context?: { json?: () => Promise<{ detail?: string; error?: string }> } } | null)?.context;
  if (ctx && typeof ctx.json === 'function') {
    try { const j = await ctx.json(); return j.detail || j.error || errMsg(e); } catch { /* fall through */ }
  }
  return errMsg(e);
}

export type ToastKind = 'ok' | 'err' | 'warn';
type ToastFn = (message: string, kind?: ToastKind) => void;
const ToastCtx = createContext<ToastFn>(() => undefined);
export const useToast = (): ToastFn => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [t, setT] = useState<{ message: string; kind: ToastKind } | null>(null);
  const timer = useRef<number | undefined>(undefined);
  const notify = useCallback<ToastFn>((message, kind = 'ok') => {
    window.clearTimeout(timer.current);
    setT({ message, kind });
    timer.current = window.setTimeout(() => setT(null), kind === 'err' ? 9000 : 4500);
  }, []);
  return (
    <ToastCtx.Provider value={notify}>
      {children}
      {t && <div className={`toast ${t.kind}`} role="status" onClick={() => setT(null)}>{t.message}</div>}
    </ToastCtx.Provider>
  );
}

export interface AsyncState<T> { data: T | null; error: string | null; loading: boolean; reload: () => void }
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]): AsyncState<T> {
  const [state, setState] = useState<{ data: T | null; error: string | null; loading: boolean }>({ data: null, error: null, loading: true });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    fn().then((d) => { if (live) setState({ data: d, error: null, loading: false }); })
        .catch((e: unknown) => { if (live) setState({ data: null, error: errMsg(e), loading: false }); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { ...state, reload: () => setTick((x) => x + 1) };
}

export function Loading({ what }: { what?: string }) { return <p className="mut" aria-live="polite">Loading{what ? ' ' + what : ''}…</p>; }
export function ErrorBox({ message, retry }: { message: string; retry?: () => void }) {
  return (
    <div className="msg err" role="alert">
      {message}{retry && <> <button type="button" className="link" onClick={retry}>Try again</button></>}
    </div>
  );
}
export function Empty({ children }: { children: ReactNode }) { return <p className="empty">{children}</p>; }
export function Pill({ status }: { status: string }) { return <span className={`pill st-${status}`}>{status.replace(/_/g, ' ')}</span>; }
export const fmtDate = (s: string | null | undefined): string => (s ? new Date(s).toLocaleString() : '—');

export interface AuthCtx {
  userId: string; email: string; perms: { permission_key: string; institution_id: string | null }[];
  can: (key: string) => boolean; aal: string; signOut: () => Promise<void>; refresh: () => void;
}
export const AuthContext = createContext<AuthCtx | null>(null);
export function useAuth(): AuthCtx {
  const c = useContext(AuthContext);
  if (!c) throw new Error('useAuth outside provider');
  return c;
}
