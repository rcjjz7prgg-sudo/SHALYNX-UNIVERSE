import { useCallback, useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { AuthContext, errMsg, Loading, useAuth, useToast } from './lib';
import type { AuthCtx } from './lib';
import type { Perm } from './types';
import Dashboard from './pages/Dashboard';
import Campuses from './pages/Campuses';
import Staff from './pages/Staff';
import Roles from './pages/Roles';
import Audit from './pages/Audit';
import Requests from './pages/Requests';
import Settings from './pages/Settings';
import Security from './pages/Security';

interface NavItem { path: string; label: string; need?: string; render: () => JSX.Element }
const NAV: NavItem[] = [
  { path: '/', label: 'Overview', need: '*', render: () => <Dashboard /> },
  { path: '/campuses', label: 'Campuses', need: 'campuses.view', render: () => <Campuses /> },
  { path: '/staff', label: 'Staff & access', need: 'admins.view', render: () => <Staff /> },
  { path: '/roles', label: 'Roles & permissions', need: 'admins.view', render: () => <Roles /> },
  { path: '/requests', label: 'Support requests', need: 'requests.view', render: () => <Requests /> },
  { path: '/audit', label: 'Audit log', need: 'audit.view', render: () => <Audit /> },
  { path: '/settings', label: 'Settings', need: 'settings.view', render: () => <Settings /> },
  { path: '/security', label: 'My security', render: () => <Security /> },
];

function useHashPath(): string {
  const read = () => (window.location.hash.replace(/^#/, '') || '/');
  const [p, setP] = useState(read);
  useEffect(() => {
    const on = () => setP(read());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return p;
}

function Login() {
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
    setBusy(false);
    if (error) { setMsg('Sign-in failed. Check your email and password.'); return; }
    setPw(''); toast('Signed in');
  }
  return (
    <main className="center">
      <form className="card narrow" onSubmit={submit}>
        <h1>SHALYNX HQ</h1>
        <p className="mut">Staff sign-in</p>
        <label htmlFor="em">Email</label>
        <input id="em" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <label htmlFor="pw">Password</label>
        <input id="pw" type="password" autoComplete="current-password" value={pw} onChange={(e) => setPw(e.target.value)} required />
        {msg && <div className="msg err" role="alert">{msg}</div>}
        <button type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p className="mut small"><a href="../accept.html">Forgot your password?</a></p>
      </form>
    </main>
  );
}

function MfaChallenge({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    try {
      const { data: f, error: fe } = await supabase.auth.mfa.listFactors();
      if (fe) throw fe;
      const factor = f.totp[0];
      if (!factor) throw new Error('No authenticator is set up for this account.');
      const { error } = await supabase.auth.mfa.challengeAndVerify({ factorId: factor.id, code: code.trim() });
      if (error) throw error;
      onDone();
    } catch (err) { setMsg(errMsg(err)); } finally { setBusy(false); }
  }
  return (
    <main className="center">
      <form className="card narrow" onSubmit={submit}>
        <h1>Two-step check</h1>
        <p className="mut">Enter the 6-digit code from your authenticator app.</p>
        <input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={(e) => setCode(e.target.value)} aria-label="6-digit code" required />
        {msg && <div className="msg err" role="alert">{msg}</div>}
        <button type="submit" disabled={busy}>{busy ? 'Checking…' : 'Verify'}</button>
        <button type="button" className="sec" onClick={onCancel}>Sign out</button>
      </form>
    </main>
  );
}

function Shell({ path }: { path: string }) {
  const auth = useAuth();
  const [open, setOpen] = useState(false);
  const items = NAV.filter((n) => !n.need || auth.can(n.need));
  const current = items.find((n) => n.path === path) ?? items[0];
  useEffect(() => { setOpen(false); }, [path]);
  return (
    <div className="shell">
      <header className="top">
        <button type="button" className="icon" aria-label="Menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>☰</button>
        <b>SHALYNX HQ</b>
        <span className="grow" />
        <span className="who">{auth.email}</span>
      </header>
      <nav className={open ? 'side open' : 'side'} aria-label="Main">
        {items.map((n) => (
          <a key={n.path} href={'#' + n.path} className={n.path === current.path ? 'on' : ''} aria-current={n.path === current.path ? 'page' : undefined}>{n.label}</a>
        ))}
        <button type="button" className="sec" onClick={() => void auth.signOut()}>Sign out</button>
      </nav>
      <main className="content">
        {auth.perms.length === 0 && (
          <div className="msg warn" role="alert">
            This account has no active staff access. If you were just invited, finish the invitation first. If two-step verification is required, enrol it under “My security”, then sign in again.
          </div>
        )}
        {current.render()}
      </main>
    </div>
  );
}

export default function App() {
  const path = useHashPath();
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [perms, setPerms] = useState<Perm[] | null>(null);
  const [aal, setAal] = useState<{ current: string; next: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  const uid = session?.user.id;
  useEffect(() => {
    if (!uid) { setPerms(null); setAal(null); return; }
    let live = true;
    (async () => {
      try {
        const a = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
        if (a.error) throw a.error;
        if (!live) return;
        setAal({ current: a.data.currentLevel ?? 'aal1', next: a.data.nextLevel ?? 'aal1' });
        const p = await supabase.rpc('my_permissions');
        if (p.error) throw p.error;
        if (live) { setPerms((p.data ?? []) as Perm[]); setError(null); }
        void supabase.rpc('staff_seen');
      } catch (e) { if (live) setError(errMsg(e)); }
    })();
    return () => { live = false; };
  }, [uid, tick]);

  const signOut = useCallback(async () => { await supabase.auth.signOut(); setPerms(null); }, []);
  const ctx = useMemo<AuthCtx | null>(() => {
    if (!session || !perms || !aal) return null;
    const keys = new Set(perms.map((p) => p.permission_key));
    return {
      userId: session.user.id, email: session.user.email ?? '', perms, aal: aal.current,
      can: (k: string) => (k === '*' ? perms.length > 0 : keys.has(k)), signOut, refresh: () => setTick((t) => t + 1),
    };
  }, [session, perms, aal, signOut]);

  if (session === undefined) return <main className="center"><Loading /></main>;
  if (!session) return <Login />;
  if (error) return <main className="center"><div className="card narrow"><div className="msg err">{error}</div><button type="button" onClick={() => setTick((t) => t + 1)}>Try again</button> <button type="button" className="sec" onClick={() => void signOut()}>Sign out</button></div></main>;
  if (!aal || !perms) return <main className="center"><Loading what="your access" /></main>;
  if (aal.next === 'aal2' && aal.current !== 'aal2') return <MfaChallenge onDone={() => setTick((t) => t + 1)} onCancel={() => void signOut()} />;
  if (!ctx) return <main className="center"><Loading /></main>;
  return <AuthContext.Provider value={ctx}><Shell path={path} /></AuthContext.Provider>;
}
